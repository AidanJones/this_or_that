import * as React from "react";

import { cn } from "./utils";

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      type={type}
      data-slot="input"
      className={cn(
        "file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 flex h-9 w-full min-w-0 px-3 py-1 text-base bg-input-background transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm shadow-[3px_3px_0px_rgba(0,0,0,0.3)]",
        "focus-visible:shadow-[5px_5px_0px_rgba(0,0,0,0.3)]",
        "aria-invalid:shadow-[3px_3px_0px_rgba(220,38,38,0.3)]",
        className,
      )}
      {...props}
    />
  );
}

export { Input };