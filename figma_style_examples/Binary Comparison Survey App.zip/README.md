
  # Binary Comparison Survey App

  This is a code bundle for Binary Comparison Survey App. The original project is available at https://www.figma.com/design/7w8NgJ87JTR5ixYJ9H6c63/Binary-Comparison-Survey-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  